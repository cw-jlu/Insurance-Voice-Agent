# 陈为｜保险复杂咨询语音 Agent

个人参赛；命题OPEN-JS-01。演示版本v0.3.0-duplex-20261014，核心v0.1.0-core-20261014。

先看 docs/31-陈为个人参赛答辩与提交说明.md：3分钟总结、7分钟现场演示、5分钟答辩准备。
正式指标见 docs/24-当前指标与验收口径.md；新包装不改变未达标项。
materials/ 保留截图和真实云连通结果；Qwen对照和合成麦克风测试明确标注，非DeepSeek正式复验。

## 复现步骤

1. 解压整个包，不要只复制网页。安装Python（推荐3.12或更高版本）。
2. 在解压目录执行 python scripts/verify_package.py 和 python scripts/verify_freeze.py。
3. 执行 python -m pip install -r requirements-demo.txt（首次安装需要网络）。
4. 执行 python -m unittest discover -s tests -q，预期143项通过；另可用Node运行 node --test tests/duplex.test.cjs（7项）。
5. 执行 python scripts/run_demo.py，打开 http://127.0.0.1:8080。
6. 无密钥时可顺序播放7轮已保存实验。T06失败和T07人工通知按原记录保留。
7. 要现场问新问题，复制.env.demo.example为.env.demo并填写DeepSeek、Qwen、腾讯ASR配置。
   执行 python scripts/check_demo.py 检查配置，然后重启服务。默认DeepSeek，Qwen只是主动选择的对照。
   Windows若Python TLS异常，可使用 python scripts/run_demo.py --native-https。
8. 语音需localhost或HTTPS、麦克风授权。点击一次开启语音后持续收音，播报中可直接插话；默认在ASR句段结束后自动发送。
   可关自动发送，先核对文字再提交。播放速度0.75–2倍；网页查看耗时、来源、已播与生成记录并导出。

## 复核实测数据

experiments/results/exp44_task_release/ 包含143题原始结果和manual_audit.json。
experiments/results/exp44_current_metrics.json 是当前汇总。
experiments/results/exp44_voice_current/voice/ 是7轮真实云服务语音实验的原始逐轮JSON。
其余历史文字结果与实验脚本保留，可按docs链接追溯；大体积录音和音频缓存不放入本包。
执行历史实验脚本可能产生付费云调用，请先读脚本说明；回放和单元测试无需调用模型。

## 当前边界

复杂题26/30=86.7%，未达90%；复杂整轮播完仍超10秒。附和/回声误停、来源支持和人工漏转未清零。
短信、真实人工接通、理赔进度接口未集成。浏览器回执不是DAC/声学验收，持续收音、插话暂停与取消已有实测；真人自然打断与物理AEC仍待验收。
当前机器尚缺DeepSeek密钥，答辩版DeepSeek完整现场链路待补配置预演；不能用Qwen成绩替代。
Docker配置提供但未实际构建；直接依赖固定，不保证传递依赖或外部模型版本永久不变。
外部服务的实时新结果可能与已保存实验不同。关闭服务会丢失内存会话，结束前导出JSON。
资料包不包含真实服务密钥；运行环境配置由接收者自行提供。
